//ProductList

import { menuData } from "@/data/menuData.json";

export default function ProductList() {
  const allProducts = menuData.flatMap((cat) => cat.products);
  return (
    <>
      <div className="menu__all-list">
        <button className="menu__btn">Btn All list</button>
        <section
          id="all-list"
          data-category="all-list"
          className="menu__category"
        >
          <h2>All products ({allProducts.length})</h2>
          <div>
            <ul>
              {allProducts.map((p) => (
                <li key={p.id}>{p.name}</li>
              ))}
            </ul>
          </div>
        </section>

        <button className="menu__btn">Btn iced-coffee</button>
        <section
          id="iced-coffee"
          data-category="iced-coffee"
          className="menu__category"
        >
          <h2>Hier is de section voor iced-coffee</h2>
          <div>Hier is de productCard iced-coffee</div>
        </section>

        <button className="menu__btn">Btn iced-boba</button>
        <section
          id="iced-boba"
          data-category="iced-boba"
          className="menu__category"
        >
          <h2>Hier is de section voor iced-boba</h2>
          <div>Hier is de productCard iced-boba</div>
        </section>

        <button className="menu__btn">Btn iced-tea</button>
        <section
          id="iced-tea"
          data-category="iced-tea"
          className="menu__category"
        >
          <h2>Hier is de section voor iced-tea</h2>
          <div>Hier is de productCard iced-tea</div>
        </section>
      </div>
    </>
  );
}
