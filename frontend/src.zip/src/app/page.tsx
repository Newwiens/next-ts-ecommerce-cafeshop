import Hero from "@/app/home/page";

export default function Home() {
  return (
    <>
      <Hero />
    </>
  );
}
