export default function Hero() {
  return (
    <>
      <div className="min-h-screen W bg-white flex items-center justify-center">
        <h1 className="text-3xl font-bold text-black">Hello World</h1>
      </div>
    </>
  );
}
